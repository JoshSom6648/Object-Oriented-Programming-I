package exercise;
/**
 * 
 * @author Joshua Sommers
 *
 */
public class Exercise13_07 {
	/** Main method */
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Create an array of five GeometricObjects
		GeometricObject[] triangle = {new Triangle(4.5, 1, 1), new Triangle(14, 1, 1),
				new Triangle(8.2, 1, 1), new Triangle(12, 1, 1), new Triangle(10, 1, 1)};
		
		// Display the area and invoke the howToColor
		// method for each GeometricObject
		for (int i = 0; i < triangle.length; i++) {
			System.out.println("\nTriangle #" + (i + 1));
			System.out.println("Area: " + triangle[i].getArea());
			System.out.println("How to color: " + ((Triangle)triangle[i]).howToColor());
		}

	}

}
