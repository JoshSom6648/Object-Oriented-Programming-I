package exercise;
 /********************************************************
 *                      Triangle                         *
 *-------------------------------------------------------*
 * -side1: double                                        *
 * -side2: double                                        *
 * -side3: double                                        *
 *-------------------------------------------------------*
 * +Triangle()                                           *
 * +Triangle(side1: double, side2: double, side3: double)*
 * +Triangle(side1: double, side2: double, side3: double,*
 *                   color: string, filled: boolean)     *
 * +getSide1(): double                                   *
 * +getSide2(): double                                   *
 * +getSide3(): double                                   *
 * +setSlide1(side1: double): void                       *
 * +setSlide2(side2: double): void                       *
 * +setSlide3(side3: double): void                       *
 ********************************************************/
public class Triangle extends GeometricObject implements Colorable{
	private double side1;
	private double side2;
	private double side3;
	String color = "white";
	
	
	public Triangle() {
		this.side1 = side1;
		this.side2 = side2;
		this.side3 = side3;
	}
	
	public Triangle(double side1, double side2, double side3) {
		color = getColor();
		this.side1 = side1;
		
	}
	
//	public void setSide(double side) {
//		this.side1 = side1;
//		this.side2 = side2;
//		this.side3 = side3;
//		
//	}
//	
//	public double getSide() {
//		return side1;
//		return side2;
//		return side3;
//	}
	
	@Override
	public double getArea() {
		return Math.pow(side1, 2);
	}
	
	@Override
	public double getPerimeter() {
		return side1 * 4;
	}
	
	@Override
	public String howToColor() {
		return "Color all three sides";
	}
	
	@Override
	public String toString() {
			return super.toString() + "\nSide: " + side1 + "\nArea: " + getArea() +
					"\nPerimeter: " + getPerimeter();
		}
	

}
