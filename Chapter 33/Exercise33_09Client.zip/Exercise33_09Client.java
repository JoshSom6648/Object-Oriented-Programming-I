package exercise;
import javafx.application.Application;
import static javafx.application.Application.launch;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;

import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.scene.control.TextInputControl;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Exercise33_09Client extends Application{
	private TextArea taServer = new TextArea();
	  private TextArea taClient = new TextArea();
	private DataInputStream fromServer;
	private DataOutputStream toServer;
	private TextInputControl ta;
	 
	  @Override // Override the start method in the Application class
	  public void start(Stage primaryStage) {
	    taServer.setWrapText(true);
	    taClient.setWrapText(true);
	    //taServer.setDisable(true);

	    BorderPane pane1 = new BorderPane();
	    pane1.setTop(new Label("History"));
	    pane1.setCenter(new ScrollPane(taServer));
	    BorderPane pane2 = new BorderPane();
	    pane2.setTop(new Label("New Message"));
	    pane2.setCenter(new ScrollPane(taClient));
	    
	    VBox vBox = new VBox(5);
	    vBox.getChildren().addAll(pane1, pane2);

	    // Create a scene and place it in the stage
	    Scene scene = new Scene(vBox, 200, 200);
	    primaryStage.setTitle("Exercise31_09Client"); // Set the stage title
	    primaryStage.setScene(scene); // Place the scene in the stage
	    primaryStage.show(); // Display the stage

	    // To complete later
	 // handle action event
	    tf.setOnAction (e -> {
	    	try {
	    		
	    		// Get the radius from the text field
	    		// read radius
	    		double radius = Double.parseDouble(tf.getText().trim());
	    		
	    		// Send the radius to the server write radius
	    		toServer.writeDouble(radius);
	    		toServer.flush();
	    		
	    		// Get area from the server read area
	    		double area = fromServer.readDouble();
	    		
	    		// Display to the text area
	    		ta.appendText("Radius is" + radius + "\n");
	    		ta.appendText("Area received from the server is "
	    				+ area + '\n');
	    	}
	    	
	    	catch (IOException ex) {
	    		System.err.println(ex);
	    	}
	    });
	    
	    try {
	    	
	    	// Create a socket to connect to the server
	    	// request connection
	    	Socket socket = new Socket("localhost", 8000);
	    	// Socket socket = new Socket("130.254.204.36, 8000);
	    	// Socket socket = new Socket socket("drake.Armstrong.edu", 8000);
	    	
	    	// Create an input stream to receive data from the server input from server
	    	fromServer = new DataInputStream(socket.getInputStream());
	    	
	    	// Create an output stream to send data to the server
	    	// output to server
	    	toServer = new DataOutputStream(socket.getOutputStream());
	    	
	    }
	    catch (IOException ex) {
	    	ta.appendText(ex.toString() + '\n');
	    }
	  }
	  
	  

	  /**
	   * The main method is only needed for the IDE with limited
	   * JavaFX support. Not needed for running from the command line.
	   */
	  public static void main(String[] args) {
	    launch(args);
	  }
	}