package exercise;
import java.util.*;

public class WordOccurrence implements Comparable<WordOccurence> {
	String word;
	Integer count;
	
	/** COnstruct an instance WordOccurence
	 * with specified word and count */
	public WordOccurrence(String word, int count) {
		this.word = word;
		this.count = count;
		
	}
	
	@Override /** Override the compareTo method in the Comparable class */
	public int compareTo(WorkOccurrence o) {
		return o.count.compareTo(count);
		
	}
	
	@Override /** Override the toString method in the */
	public String toString() {
		return word + "=" + count;
	}
	

}
