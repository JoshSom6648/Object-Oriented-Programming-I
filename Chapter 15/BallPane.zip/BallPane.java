package exercise;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.paint.Color;
import javafx.scene.layout.Pane;
import javafx.scene.shape.Circle;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class BallPane extends Pane {
	private Circle circle = new Circle(20, 20, 20);
	
	//Construct a default ball pane
	public BallPane() {
		circle.setFill(Color.WHITE);
		circle.setStroke(Color.BLACK);
		getChildren().add(circle); // Place a ball into this pane
		
	}
	
	// Move ball left
	public void left() {
		circle.setCenterX(circle.getCenterX() > circle.getRadius() ?
				circle.getCenterX() - 20 : circle.getCenterX());
		circle.setCenterY(circle.getCenterY());
		
	}
	
	// Move ball right
		public void right() {
			circle.setCenterX(circle.getCenterX() > circle.getRadius() ?
					circle.getCenterX() - 20 : circle.getCenterX());
			circle.setCenterY(circle.getCenterY());
			
		}
		
		// Move ball up
		public void up() {
			circle.setCenterX(circle.getCenterX() > circle.getRadius() ?
					circle.getCenterX() - 20 : circle.getCenterX());
			circle.setCenterY(circle.getCenterY());
			
		}
		
		// Move ball down
		public void down() {
			circle.setCenterX(circle.getCenterX() > circle.getRadius() ?
					circle.getCenterX() - 20 : circle.getCenterX());
			circle.setCenterY(circle.getCenterY());
			
		}
	

}
