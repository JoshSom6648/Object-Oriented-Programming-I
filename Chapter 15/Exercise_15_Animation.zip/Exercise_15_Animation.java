package exercise;
import javafx.animation.PathTransition;
import javafx.animation.Timeline;
import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Polygon;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Exercise_15_Animation extends Application {
	@Override // Override the start method in the Application class
	public void start(Stage primaryStage) {
		// TODO Auto-generated method stub
		// Create a pane
		Pane pane = new Pane();
		
		// Create a rectangle
		Rectangle rectangle = new Rectangle(0, 0, 25, 50);
		rectangle.setFill(Color.ORANGE);
		
		// Create a Polygon
		Polygon polygon = new Polygon(125, 100, 50);
		polygon.setFill(Color.WHITE);
		polygon.setStroke(Color.BLACK);
		
		// Add polygon and rectangle to the pane
		pane.getChildren().add(polygon);
		pane.getChildren().add(rectangle);
		
		// Create a path transition
		PathTransition pt = new PathTransition();
		pt.setDuration(Duration.millis(4000));
		pt.setPath(polygon);
		pt.setNode(rectangle);
		pt.setOrientation(
				PathTransition.OrientationType.ORTHOGONAL_TO_TANGENT);
		pt.setCycleCount(Timeline.INDEFINITE);
		pt.setAutoReverse(true);
		pt.play(); // Start animation
		polygon.setOnMousePressed(e ->
		pt.pause());
		polygon.setOnMouseReleased(e ->
		pt.play());
		
		// Create a scene and place it in the stage
		Scene scene = new Scene(pane, 250, 200);
		primaryStage.setTitle("Exercise_15_Animation"); // Set the stage title
		primaryStage.setScene(scene); // Place the scene in the stage
		primaryStage.show(); // Display the stage
	}

}
