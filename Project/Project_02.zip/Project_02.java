package exercise;
import java.util.Scanner;
public class Project_02 {
	private static final String Choice = null;

	private static final String H = null;

	private static final String S = null;

	private static final String G = null;

	private static final String R = null;

	private static final Scanner scan = null;
	public static void main(String [] args) {
		Scanner scan = new Scanner (System.in);

		
		String q1 = "Dawn or Dusk?\n"
				+ "(a)Dawn\n(b)Dusk\n";
		
		String q2 = "Moon or Stars\n"
				+ "(a)Moon\n(b)Stars\n";
		
		String q3 = "Which of the following would you most hate people call you\n"
				+ "(a)Ordinary\n(b)Ignorant\n(c)Cowardly\n(d)Selfish\n";
		
		String q4 = "After you have died, what would you most like people to do when they hear your name\n"
				+ "(a)Miss you, but smile\n(b)Ask for more stories about your adventures\n(c)Think with admiration of your achievements\n(d)I don't care what people think of me after I'm dead, it's what they think of me while I'm alive that counts\n";
		
		String q5 = "How would you like to be known to history?\n"
				+ "(a)The Wise\n(b)The Good\n(c)The Great\n(d)The Bold\n";
		
		String q6 = "Given the choice, would you rather invent a potion that would guarantee you:\n"
				+ "(a)Love?\n(b)Glory?\n(c)Wisdom?\n(d)Power\n";
		
		String q7 = "Once every century, the Flutterby bush produces flowers that adapt their scent to attract the unwary. If it lured you, it would smell of:\n"
				+ "(a)A crackling log fire\n(b)The sea\n(c)Fresh parchment\n(d)Home\n";
		
		String q8 = "Four goblets are placed before you. Which would you choose to drink?\n"
				+ "(a)The foaming, frothing, silvery liquid that sparkles as though containing ground diamonds.\n(b)The smooth, thick, richly purple drink that gives off a delicious smell of chocolate and plums.\n(c)The golden liquid is so bright that it hurts the eye, and it makes sunspots dance all around the room.\n(d)The mysterious black liquid that gleams like ink gives off fumes that make you see strange visions.\n";
		
		String q9 = "What kind of instrument most pleases your ear?\n"
				+ "(a)The violin\n(b)The trumpet\n(c)The piano\n(d)The drum\n";
		
		String q10 = "You enter an enchanted garden. What would you be most curious to examine first?\n"
				+ "(a)The silver-leafed tree bearing golden apples\n(b)The fat red toadstools that appear to be talking to each other\n(c)The bubbling pool, in the depths of which something luminous is swirling\n(d)The statue of an old wizard with a strangely twinking eye\n";
		
		String q11 = "Four boxes are placed before you. Which would you try and open?\n"
				+ "(a)The small tortoiseshell box, embellished with gold, inside which some small creature seems to be squeaking\n(b)The gleaming jet black box with a silver lock and key, marked with a mysterious rune that you know to be the mark of Merlin.\n(c)The ornate golden casket, standing on clawed feet, whose inscription warns that both secret knowledge and unbearable temptation lie within.\n(d)The small pewter box, unassuming and plain, with a scratched message upon it that reads 'I open only for the worthy.'\n";
		
		String q12 = "A troll has gone berserk in the Headmaster's study at Hogwarts. It is about smashing, crushing, and tearing several irreplaceable items and treasures. In which order would you rescue these objects from the troll's club, if you could?\n"
				+ "(a)First, a nearly perfected cure for dragon pox. The student records go back 1000 years. Finally, a mysterious handwritten book full of strange runes.\n(b)First, student records going back 1000 years. Then a mysterious handwritten book full of strange runes. Finally, a nearly perfected cure for dragon pox.\n(c)First, a mysterious handwritten book full of strange runes. Then a nearly perfected cure for Dragon pox. Finally, student records go back 1000 years.\n(d)First, a nearly perfected cure for dragon pox. Then a mysterious handwritten book full of strange runes. Finally, student records go back 1000 years.\n(e)First, student records going back 1000 years. Then, a nearly perfected cure for dragon pox. Finally, a mysterious handwritten book full of strange runes.\n(f)First, a mysterious handwritten book full of strange runes. The student records go back 1000 years. Finally, a nearly perfected cure for dragon pox.\n";
		
		String q13 = "Which of the following do you find most difficult to deal with?\n"
				+ "(a)Hunger\n(b)Cold\n(c)Loneliness\n(d)Boredom\n(e)Being ignored\n";
		
		String q14 = "Which would you rather be:\n"
				+ "(a)Envied?\n(b)Imitated?\n(c)Trusted?\n(d)Praised?\n(e)Liked?\n(f)Feared?\n";
		
		String q15 = "If you could have any power, which would you choose?\n"
				+ "(a)The power to read minds\n(b)The power of invisibility\n(c)The power of superhuman strength\n(d)The power to speak to animals\n(e)The power to change the past\n(f)The power to change your appearance at will\n";
		
		String q16 = "What are you most looking forward to learning at Hogwarts?\n"
				+ "(a)Apparition and Disapparition(being able to materialize and dematerialize at will)\n(b)Transfiguration(turning one object into another object)\n(c)Flying on a broomstick\n(d)Hexes and jinxes\n(e)All about magical creatures, and how to befriend/care for them\n(f)Secrets about the castle\n(g)Every area of magic I can\n";
		
		String q17 = "Which of the following would you most like to study?\n"
				+ "(a)Centaurs\n(b)Goblins\n(c)Merpeople\n(d)Ghosts\n(e)Vampires\n(f)Werewolves\n(g)Trolls\n";
		
		String q18 = "You and two friends need to cross a bridge guarded by a river troll who insists on fighting one of you before he will let all of you pass. Do you:\n"
				+ "(a)Attempt to confuse the troll into letting all three of you pass without fighting?\n(b)Suggest drawing lots to decide which of you will fight.\n(c)Suggest that all three of you should fight(without telling the troll).\n(d)Volunteer to fight?\n";
		
		String q19 = "One of your housemates cheated in a Hogwarts exam using a Self-Spelling Quill. Now he has come top of the class in Charms, beating you into second place. Professor Flitwick is suspicious of what happened. He draws you to one side after his lesson and asks you whether or not your classmate used a forbidden quill. What do you do?\n"
				+ "(a)Lie and say you don't know (but hope that somebody else tells Professor Flitwick the truth).\n(b)Tell Professor Flitwick that he ought to ask your classmate(and resolve to tell your classmate that if he doesn't tell the truth, you will).\n(c)Tell Professor Flitwick the truth. If your classmate is prepared to win by cheating, he deserves to be found out. Also, as you are both in the same house, any points he loses will be regained by you, for coming first in his place.\n(d)You would not wait to be asked to tell Professor Flitwick the truth. If you knew that somebody was using a forbidden quill, you would tell the teacher before the exam started.\n";
		
		String q20 = "A Muggle confronts you and says that they are sure you are a witch or wizard. Do you:\n"
				+ "(a)Ask what makes them think so.\n(b)Agree, and ask whether they'd like a free sample of a jinx.\n(c)Agree, and walk away, leaving them to wonder whether you are bluffing.\n(d)Tell them that you are worried about their mental health, and offer to call a doctor.\n";
		
		String q21 = "Which nightmare would frighten you most?\n"
				+ "(a)Standing on top of something very high and realizing suddenly that there are no hands- or footholds, nor any barrier to stop you from falling.\n(b)An eye at the keyhole of the dark, windowless room in which you are locked.\n(c)Waking up to find that neither your friends nor your family have any idea who you are.\n(d)Being forced to speak in such a silly voice that hardly anyone can understand you, and everyone laughs at you\n";
		
		String q22 = "Which road tempts you most?\n"
				+ "(a)The wide, sunny, grassy lane\n(b)The narrow, dark, latern-lit alley\n(c)The twisting, leaf-strewn path through woods\n(d)The cobbled street lined with ancient buildings\n";
		
		String q23 = "Late at night, walking alone down the street, you hear a peculiar cry that you believe to have a magical source. Do you:\n"
				+ "(a)Proceed with caution, keeping one hand on your concealed wand and an eye out for any disturbance.\n(b)Draw your wand and try to discover the source of the noise.\n(c)Draw your wand and stand your ground.\n(d)Withdraw into the shadows to await developments, while mentally reviewing the most appropriate defensive and offensive spells, should trouble occur?\n";
		
		String q24 = "If you were attending Hogwarts, which pet would you choose to take with you?\n"
				+ "(a)Tabby Cat\n(b)Siamese Cat\n(c)Ginger Cat\n(d)Black Cat\n(e)White Cat\n(f)Tawny Owl\n(g)Screech Owl\n(h)Brown Owl\n(i)Snowy Owl\n(j)Barn Owl\n(k)Common toad\n(l)Natterjack toad\n(m)Dragon toad\n(n)Harlequin toad\n(o)Three toed tree toad\n";
		
		String q25 = "Black or White?\n"
				+ "(a)Black\n(b)White\n";
		
		String q26 = "Heads or Tails?\n"
				+ "(a)Heads\n(b)Tails\n";
		
		String q27 = "Left or Right?\n"
				+ "(a)Left\n(b)Right\n";
		
		Question[] questions = {
				new Question(q1, "G:a, R:a, H:b, S:b"),
				new Question(q2, "G:b, R:a, H:b, S:a"),
				new Question(q3, "G:c, R:b, H:d, S:b"),
				new Question(q4, "G:b, R:c, H:a, S:d"),
				new Question(q5, "G:d, R:a, H:b, S:c"),
				new Question(q6, "G:b, R:c, H:a, S:d"),
				new Question(q7, "G:a, R:c, H:d, S:b"),
				new Question(q8, "G:c, R:a, H:b, S:d"),
				new Question(q9, "G:d, R:c, H:b, S:a"),
				new Question(q10, "G:d, R:a, H:b, S:c"),
				new Question(q11, "G:d, R:c, H:a, S:b"),
				new Question(q12, "G:a/d, R:c/f, H:a/e, S:b/f"),
				new Question(q13, "G:c/d, R:a/e, H:a/b/c, S:b/d/e"),
				new Question(q14, "G:c/d, R:a/b, H:c/e, S:a/f"),
				new Question(q15, "G:b/, R:a/d/f, H:c/d, S:a/e"),
				new Question(q16, "G:a/c/f, R:b/g, H:b/c/e, S:a/d"),
				new Question(q17, "G:a/d/f, R:a/b/d, H:c/f/g, S:c/e/g"),
				new Question(q18, "G:d, R:a, H:b, S:c"),
				new Question(q19, "G:b, R:c, H:a, S:d"),
				new Question(q20, "G:c, R:a, H:d, S:b"),
				new Question(q21, "G:b, R:a, H:c, S:d"),
				new Question(q22, "G:c, R:d, H:a, S:b"),
				new Question(q23, "G:b, R:a, H:d, S:c"),
				new Question(q24, "G:a/i/m, R:f/g/h/j, H:i/k/l/m/n/o, S:b/c/d/e"),
				new Question(q25, "G:a, R:b, H:b, S:a"),
				new Question(q26, "G:b, R:a, H:a, S:b"),
				new Question(q27, "G:b, R:a, H:b, S:a")
				
		};
		takeTest(questions);
}
			
		
		public static void takeTest(Question[] questions) {
			int score = 0;
			Scanner keyboardInput = new Scanner(System.in);
			
			for(int i = 0; i < questions.length; i++) {
				System.out.println(questions[i].prompt);
				String answer = keyboardInput.nextLine();
				if(answer.contains(questions[i].answer)) {
					int Choice = scan.nextInt();
					score++;
				}
				else if(Choice == G) {
					System.out.println("You got house Gryffindor " + score + "G" + questions.length);

				    score++;
				System.out.printf("score: %d\n");
				}
				else if(Choice == S) {
					System.out.println("You got house Slytherin " + score + "S" + questions.length);

				    score++;
				System.out.printf("score: %d\n");
				}
				else if(Choice == H) {
					System.out.println("You got house Hufflepuff " + score + "H" + questions.length);

				    score++;
				    System.out.printf("score: %d\n");
			    	}
				else if(Choice == R) {
				    System.out.println("You got house Ravenclaw " + score + "R" + questions.length);
				    
				    score++;
				    System.out.printf("score: %d\n");
				
			
				
			}
}
		}
		}
		

