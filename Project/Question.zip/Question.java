package exercise;
/**
 * 
 * @author Joshua Sommers
 *@date 03/27/2023
 */
public class Question {
	String prompt;
	String answer;

	public Question(String prompt, String answer) {
		this.prompt = prompt;
		this.answer = answer;
		
	}
}
