package exercise;
import javafx.application.Application;
import javafx.event.ActionEvent;
//import javafx.fxml.FXML;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputControl;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class Project_03 extends Application {
	private TextInputControl input;
	private TextInputControl output;

	@Override // Override the start method in the Application class
	public void start(Stage primaryStage) {
	JapaneseTranslator japaneseTranslator = new JapaneseTranslator();
	TextField tf = new TextField();
	
	}
	void translate(ActionEvent event) {
		Project_03 japaneseTranslator = null;
		String translated = japaneseTranslator.translate(input.getText());
		if(translated != null) {
			output.setText(translated);
		}else {
			output.setText("Not Possible");
		}

	}

    private String translate(String text) {
		// TODO Auto-generated method stub
		return null;
	}
	public static void main(String[] args) {
        launch(args);
    }
	}

