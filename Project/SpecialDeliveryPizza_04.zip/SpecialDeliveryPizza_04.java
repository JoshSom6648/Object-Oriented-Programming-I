package exercise;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

public class SpecialDeliveryPizza_04 extends Application {
	 @Override
	    public void start(Stage stage) {
	        GridPane gridPane = new GridPane();
	        gridPane.setPadding(new Insets(10));

	        Label sizeLabel = new Label("Size:");
	        ComboBox<String> sizeComboBox = new ComboBox<>();
	        sizeComboBox.getItems().addAll("Small", "Medium", "Large");

	        Label crustLabel = new Label("Crust:");
	        ComboBox<String> crustComboBox = new ComboBox<>();
	        crustComboBox.getItems().addAll("Thin", "Thick", "Stuffed");

	        Label toppingsLabel = new Label("Toppings:");
	        TextField toppingsTextField = new TextField();

	        Button makePizzaButton = new Button("Make Pizza");

	        gridPane.add(sizeLabel, 0, 0);
	        gridPane.add(sizeComboBox, 1, 0);
	        gridPane.add(crustLabel, 0, 1);
	        gridPane.add(crustComboBox, 1, 1);
	        gridPane.add(toppingsLabel, 0, 2);
	        gridPane.add(toppingsTextField, 1, 2);
	        gridPane.add(makePizzaButton, 1, 3);

	        makePizzaButton.setOnAction(e -> {
	            String size = sizeComboBox.getSelectionModel().getSelectedItem();
	            String crust = crustComboBox.getSelectionModel().getSelectedItem();
	            String toppings = toppingsTextField.getText();

	            System.out.println("Pizza size: " + size);
	            System.out.println("Pizza crust: " + crust);
	            System.out.println("Pizza toppings: " + toppings);
	        });

	        Scene scene = new Scene(gridPane, 400, 300);
	        stage.setScene(scene);
	        stage.show();
	    }

	    public static void main(String[] args) {
	        launch(args);
	    }
	} 