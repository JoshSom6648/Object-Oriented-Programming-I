package exercise;
import java.util.*;

public class Test {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// Create a list of Integers
		Integer[] intArray = {new Integer(2), new Integer(4),
		new Integer(3)};
		ArrayList<Integer> intList =
				new ArrayList<>(Arrays.asList(intArray));
		
		// Create a list of characters
		Character[] charArray = {new Character('a'),
				new Character('J'), new Character('r')};
		ArrayList<Character> charList =
				new ArrayList<>(Arrays.asList(charArray));
		
		// Create a list of Strings
		String[] stringArray = {"Tom", "Susan", "Kim"};
		ArrayList<String> stringList =
				new ArrayList<>(Arrays.asList(stringArray));
		
		// Sort the lists
		Exercise_19_09.sort(intList);
		Exercise_19_09.sort(doubleList);
		Exercise_19_09.sort(charList);
		Exercise_19_09.sort(stringList);
		
		// Display the sorted lists
		System.out.println("Sorted Integer objects: " + intList);
		System.out.println("Sorted Double objects: " + doubleList);
		System.out.println("Sorted Character objects: " + charList);
		System.out.println("Sorted String objects: " + stringList);
		}

	}


