package exercise;
import java.util.ArrayList;
import java.util.Scanner;

public class Exercise_25_03 {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner input = new Scanner(System.in);
		Integer[] numbers = new Integer[10];
		
		// Prompt the user to enter 10 integers
		System.out.print("Enter 10 integers: ");
		for (int i=0; i < numbers.length; i++)
			numbers[i] = input.nextInt();
		
		// Create Integer BST
		BST<Integer> intTree = new BST<>(numbers);
		
		// Traverse tree inorder
		System.out.print("Tree inorder: ");
		intTree.inorder();
		System.out.println();

	}

}
